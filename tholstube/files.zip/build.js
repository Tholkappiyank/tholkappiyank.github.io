#!/usr/bin/env node
'use strict';

// ──────────────────────────────────────────────────────────────
// BUILD SCRIPT — TubeVault / TholsStudio
//
// Single source of truth for the category pages is `page-template.html`
// (a full page with {{PLACEHOLDER}} tokens). This script:
//   1. Generates one page per category listed in categories.json.
//      The .html pages stay at the repo root; each category's JS files
//      (config seeds + page-template.js) are written into a <id>/ folder, so
//      e.g. music.html references music/music-collections.js and
//      music/page-template.js.
//   2. Generates <id>/page-template.js per category — the same template as a
//      JS string so the in-browser "Create category…" feature reuses the exact
//      same markup (works on GitHub Pages AND when opened via file://).
//
// The per-category config seeds (*-collections.js / *-playlist.js / *-watched.js)
// are source data and are committed inside each <id>/ folder (see git mv), not
// generated here.
//
// Run with:  node build.js
// No dependencies — plain Node, ships on GitHub Pages as static output.
// ──────────────────────────────────────────────────────────────

const fs = require('fs');
const path = require('path');
const { renderTemplate } = require('./template-tokens.js');

const DIR = __dirname;

// Categories are listed in categories.json — the same "collections" shape as
// the per-category *-collections.js files: { collections: [ { id, name, color,
// groups, ungrouped }, ... ] }. That file is the single source of truth for
// which category pages get built (groups/ungrouped are ignored here).
const CATEGORIES_FILE = path.join(DIR, 'categories.json');

function loadCategories() {
  if (!fs.existsSync(CATEGORIES_FILE)) {
    console.error('ERROR: categories.json not found next to build.js');
    process.exit(1);
  }
  let data;
  try {
    data = JSON.parse(fs.readFileSync(CATEGORIES_FILE, 'utf8'));
  } catch (e) {
    console.error('ERROR: categories.json is not valid JSON: ' + e.message);
    process.exit(1);
  }
  const list = Array.isArray(data) ? data : data.collections;
  if (!Array.isArray(list)) {
    console.error('ERROR: categories.json must contain a "collections" array');
    process.exit(1);
  }
  const apps = [];
  // Tracks ids/display-names we've already seen so copy-paste duplicates
  // (like a second category accidentally keeping the first one's "name")
  // get caught here instead of shipping quietly into generated pages.
  const seenIds = new Map();    // lowercased id -> entry number that used it first
  const seenLabels = new Map(); // lowercased display name -> id that used it first
  list.forEach((c, idx) => {
    const id = c.id;
    const label = c.name || id;
    const color = c.color || '#5C6BC0';
    if (!id || !/^[a-z0-9-]+$/i.test(id)) {
      console.warn(`! Skipping invalid category on entry ${idx + 1}: "${id}"`);
      return;
    }

    // Duplicate id is fatal: the second entry would silently overwrite the
    // first one's generated <id>.html / <id>/ folder.
    const idKey = id.toLowerCase();
    if (seenIds.has(idKey)) {
      console.error(
        `ERROR: duplicate category id "${id}" (categories.json entries ${seenIds.get(idKey)} and ${idx + 1}). ` +
        `Every category needs a unique id, or the second one overwrites the first one's page.`
      );
      process.exit(1);
    }
    seenIds.set(idKey, idx + 1);

    // Duplicate display name is only ever a warning — two categories can
    // legitimately want the same look, but it's usually a copy/paste slip
    // (e.g. a category whose "name" field still says the old category's
    // name), so flag it without blocking the build.
    const labelKey = label.toLowerCase();
    if (seenLabels.has(labelKey)) {
      console.warn(
        `! "${id}" and "${seenLabels.get(labelKey)}" both display as "${label}" — ` +
        `double check that's intentional (not blocking the build).`
      );
    } else {
      seenLabels.set(labelKey, id);
    }

    apps.push({ id, label, color });
  });
  if (!apps.length) {
    console.error('ERROR: categories.json contained no valid categories');
    process.exit(1);
  }
  return apps;
}

// Generates the three per-category seed files (collections / playlist /
// watched) so a freshly built page is self-sufficient on first load and the
// app initializes (COLLECTION_COLORS etc.) without a manual commit step.
// Each seed mirrors the structure produced by the in-app "Create category…"
// feature (see buildCategory* in app.js). The collections seed ships one
// empty default collection keyed to the app id/name/color.
const COLLECTION_COLORS_BLOCK = `[
  '#5C6BC0', '#EF5350', '#26A69A', '#FFA726',
  '#66BB6A', '#AB47BC', '#29B6F6', '#FF7043',
  '#78909C', '#EC407A'
]`;

function buildCollectionsSeed(app) {
  return `// --------------------------------------------------------------
// COLLECTIONS CONFIG — ${app.label}
// Generated by build.js. Edit freely; to apply as defaults, clear localStorage.
// --------------------------------------------------------------

const COLLECTION_COLORS = ${COLLECTION_COLORS_BLOCK};

const DEFAULT_COLLECTIONS = [
  {
    id: ${JSON.stringify(app.id)},
    name: ${JSON.stringify(app.label)},
    color: ${JSON.stringify(app.color)},
    groups: {},
    ungrouped: []
  }
];
`;
}

function buildPlaylistSeed() {
  return `// --------------------------------------------------------------
// PLAYLIST CONFIG
// Generated by build.js. Create playlists in the app.
// --------------------------------------------------------------

const DEFAULT_PLAYLISTS = [];
`;
}

function buildWatchedSeed() {
  return `// --------------------------------------------------------------
// WATCHED HISTORY
// Generated by build.js.
// --------------------------------------------------------------

const WATCHED_VIDEO_IDS = [];
`;
}

// Writes the three seed files into the category's <id>/ folder — but only if
// they don't already exist, so re-running build.js never clobbers a category's
// curated collections / videos / playlists / watched history (source data built
// up in the app). Mirrors the "keep existing test fixtures" handling below.
function writeCategorySeeds(app) {
  const base = path.join(DIR, app.dir);
  const seeds = [
    [`${app.id}-collections.js`, buildCollectionsSeed(app)],
    [`${app.id}-playlist.js`, buildPlaylistSeed()],
    [`${app.id}-watched.js`, buildWatchedSeed()],
  ];
  seeds.forEach(([rel, contents]) => {
    const file = path.join(base, rel);
    if (!fs.existsSync(file)) {
      writeFileEnsureDir(file, contents);
      console.log(`✓ generated ${app.dir}${rel}`);
    } else {
      console.log(`• kept existing ${app.dir}${rel} (preserve)`);
    }
  });
}

function writeFileEnsureDir(file, contents) {
  const dir = path.dirname(file);
  if (dir && dir !== '.' && !fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, contents);
}

function main() {
  const templatePath = path.join(DIR, 'page-template.html');
  if (!fs.existsSync(templatePath)) {
    console.error('ERROR: page-template.html not found next to build.js');
    process.exit(1);
  }
  const template = fs.readFileSync(templatePath, 'utf8');

  // 1) Category pages from categories.json (HTML at root, JS in <id>/ folders)
  const APPS = loadCategories();
  // Built once from the manifest and reused for every page's {{BUILTIN_APPS_JS}}
  // token — the file:// fallback list for the in-app category switcher, so it
  // can't drift between pages (every page embeds the same, full list).
  const builtinApps = APPS.map(a => ({
    id: a.id, name: a.label, color: a.color, file: `${a.id}.html`,
  }));

  APPS.forEach(app => {
    app.dir = app.id + '/';
    const html = renderTemplate(template, { id: app.id, label: app.label, color: app.color, dir: app.dir, builtinApps });
    fs.writeFileSync(path.join(DIR, `${app.id}.html`), html);
    console.log(`✓ generated ${app.id}.html`);

    // page-template.js lives inside the category folder
    writeFileEnsureDir(
      path.join(DIR, app.dir, 'page-template.js'),
      'window.PAGE_TEMPLATE = ' + JSON.stringify(template) + ';\n'
    );
    console.log(`✓ generated ${app.dir}page-template.js`);

    // Seed files so the page initializes without a manual commit step
    writeCategorySeeds(app);
  });

  // 2) Self-contained feature test page (HTML at root, JS in test/ folder)
  const testApp = { id: 'test', label: 'Test', color: '#5C6BC0', dir: 'test/' };
  let testHtml = renderTemplate(template, { id: testApp.id, label: testApp.label, color: testApp.color, dir: testApp.dir, builtinApps });
  testHtml = testHtml.replace('</body>', '<script src="tests.js"></script>\n</body>');
  fs.writeFileSync(path.join(DIR, 'tests.html'), testHtml);
  writeFileEnsureDir(
    path.join(DIR, 'test', 'page-template.js'),
    'window.PAGE_TEMPLATE = ' + JSON.stringify(template) + ';\n'
  );
  console.log('✓ generated tests.html + test/page-template.js');

  // The test page references test/test-collections.js, test/test-playlist.js,
  // test/test-watched.js. These are hand-maintained fixtures (the feature
  // tests assert against their demo data); writeCategorySeeds skips existing
  // files, so the committed fixtures are preserved.
  writeCategorySeeds(testApp);

  console.log('done');
}

main();
